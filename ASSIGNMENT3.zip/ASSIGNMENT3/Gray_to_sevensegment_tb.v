`timescale 1ns/1ps

module Gray_to_sevensegment_tb;

reg G2, G1, G0;

wire a, b, c, d, e, f, g;


Gray_to_sevensegment uut (
    .G2(G2),
    .G1(G1),
    .G0(G0),
    .a(a),
    .b(b),
    .c(c),
    .d(d),
    .e(e),
    .f(f),
    .g(g)
);

initial begin

 
    $dumpfile("gray.vcd");
    $dumpvars(0, Gray_to_sevensegment_tb);

    $display("G2 G1 G0 | a b c d e f g");


    $monitor("%b  %b  %b  | %b %b %b %b %b %b %b",
              G2,G1,G0,a,b,c,d,e,f,g);


    G2=0; G1=0; G0=0; #10; //0
    G2=0; G1=0; G0=1; #10; //1
    G2=0; G1=1; G0=1; #10; //2
    G2=0; G1=1; G0=0; #10; //3
    G2=1; G1=1; G0=0; #10; //4
    G2=1; G1=1; G0=1; #10; //5
    G2=1; G1=0; G0=1; #10; //6
    G2=1; G1=0; G0=0; #10; //7

    $finish;

end

endmodule