module Gray_to_sevensegment(
    input G2,
    input G1,
    input G0,
    output a,
    output b,
    output c,
    output d,
    output e,
    output f,
    output g
);

assign a = (G0 & G2) | (G1 & ~G2) | (~G0 & ~G1);

assign b = (~G0) | (~G2);

assign c = G2 | (~G0) | (~G1);

assign d = (G0 & G2) | (G1 & ~G2) | (~G0 & ~G2);

assign e = (G0 & G1 & ~G2) |
           (G0 & G2 & ~G1) |
           (~G0 & ~G1 & ~G2);

assign f = (G0 & G2) |
           (G1 & G2) |
           (~G0 & ~G1 & ~G2);

assign g = G1 | (G0 & G2);

endmodule